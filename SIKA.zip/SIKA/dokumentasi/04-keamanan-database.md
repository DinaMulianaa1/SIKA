\# 4. KEAMANAN DATABASE SIKA



\## 4.1 Pendahuluan



Keamanan database bertujuan untuk melindungi data agar hanya dapat diakses dan dikelola oleh pengguna yang memiliki hak akses.



\## 4.2 Membuat Akun Pengguna



Database SIKA menggunakan akun khusus bernama `sika\_app`.



Perintah SQL:



```sql

CREATE USER 'sika\_app'@'localhost' IDENTIFIED BY 'SikaApp2026!';

```



Catatan: Jika akun sudah pernah dibuat, MariaDB dapat menampilkan error 1396. Periksa akun terlebih dahulu sebelum membuatnya kembali.



\## 4.3 Memberikan Hak Akses



Memberikan hak akses kepada pengguna `sika\_app`:



```sql

GRANT SELECT, INSERT, UPDATE, DELETE ON sika\_db.\* TO 'sika\_app'@'localhost';

```



Hak akses yang diberikan:



1\. SELECT: membaca data.

2\. INSERT: menambahkan data.

3\. UPDATE: mengubah data.

4\. DELETE: menghapus data.



\## 4.4 Memeriksa Hak Akses



Perintah untuk memeriksa hak akses pengguna:



```sql

SHOW GRANTS FOR 'sika\_app'@'localhost';

```



\## 4.5 Menguji Akun Pengguna



Keluar dari MariaDB:



```sql

EXIT;

```



Masuk menggunakan akun aplikasi melalui CMD Windows:



```cmd

mysql -u sika\_app -p

```



Memilih database:



```sql

USE sika\_db;

```



Menguji hak akses membaca data:



```sql

SELECT \* FROM mahasiswa;

```



\## 4.6 Kesimpulan



Penggunaan akun khusus `sika\_app` membantu membatasi akses pengguna terhadap database SIKA. Hak akses diberikan sesuai kebutuhan agar pengelolaan database lebih aman.

