\# 2. STRUKTUR DATABASE SIKA



\## 2.1 Membuat Database



Database SIKA dibuat menggunakan MariaDB melalui XAMPP.



Perintah SQL:



```sql

CREATE DATABASE sika\_db CHARACTER SET utf8mb4 COLLATE utf8mb4\_unicode\_ci;

```



Memilih database:



```sql

USE sika\_db;

```



\## 2.2 Tabel Database



Database SIKA memiliki empat tabel utama:



1\. `prodi` – menyimpan data program studi.

2\. `mahasiswa` – menyimpan data mahasiswa.

3\. `mata\_kuliah` – menyimpan data mata kuliah.

4\. `krs` – menyimpan data pengambilan mata kuliah oleh mahasiswa.



\## 2.3 Struktur Tabel



\### A. Tabel prodi



| Kolom | Tipe Data | Keterangan |

|---|---|---|

| id\_prodi | INT | Primary Key, Auto Increment |

| kode\_prodi | VARCHAR(10) | Kode program studi |

| nama\_prodi | VARCHAR(100) | Nama program studi |



\### B. Tabel mahasiswa



| Kolom | Tipe Data | Keterangan |

|---|---|---|

| nim | VARCHAR(20) | Primary Key |

| nama | VARCHAR(100) | Nama mahasiswa |

| email | VARCHAR(120) | Email mahasiswa |

| angkatan | YEAR | Tahun angkatan |

| id\_prodi | INT | Foreign Key |

| created\_at | TIMESTAMP | Waktu pembuatan data |



\### C. Tabel mata\_kuliah



| Kolom | Tipe Data | Keterangan |

|---|---|---|

| kode\_mk | VARCHAR(15) | Primary Key |

| nama\_mk | VARCHAR(100) | Nama mata kuliah |

| sks | TINYINT UNSIGNED | Jumlah SKS |

| semester | TINYINT UNSIGNED | Semester mata kuliah |



\### D. Tabel krs



| Kolom | Tipe Data | Keterangan |

|---|---|---|

| id\_krs | INT | Primary Key, Auto Increment |

| nim | VARCHAR(20) | Foreign Key mahasiswa |

| kode\_mk | VARCHAR(15) | Foreign Key mata\_kuliah |

| tahun\_akademik | VARCHAR(9) | Tahun akademik |

| semester\_ambil | ENUM | Ganjil atau Genap |



\## 2.4 Relasi Antar Tabel



Relasi database SIKA:



\- `prodi` berhubungan dengan `mahasiswa` melalui `id\_prodi`.

\- `mahasiswa` berhubungan dengan `krs` melalui `nim`.

\- `mata\_kuliah` berhubungan dengan `krs` melalui `kode\_mk`.



\## 2.5 Pemeriksaan Struktur Database



Perintah untuk melihat seluruh tabel:



```sql

SHOW TABLES;

```



Perintah untuk melihat struktur tabel:



```sql

DESCRIBE prodi;

DESCRIBE mahasiswa;

DESCRIBE mata\_kuliah;

DESCRIBE krs;

```



\## 2.6 Kesimpulan



Database SIKA terdiri dari empat tabel utama yang saling berhubungan menggunakan Primary Key dan Foreign Key. Struktur ini digunakan untuk mengelola data program studi, mahasiswa, mata kuliah, dan KRS.

