\# DATABASE SIKA



\## 1. Pendahuluan



Database SIKA merupakan sistem basis data yang digunakan untuk mengelola informasi akademik mahasiswa.



\### Tujuan Praktikum

1\. Membuat database menggunakan MariaDB.

2\. Membuat tabel dan relasi antar tabel.

3\. Mengelola data menggunakan perintah SQL.

4\. Memahami penggunaan JOIN dan fungsi agregasi.

5\. Menerapkan keamanan database.

6\. Melakukan backup dan restore database.



\### Tools yang Digunakan

\- XAMPP

\- MariaDB

\- Command Prompt (CMD)

\- MySQL/MariaDB Client



\### Nama Database

`sika\_db`

