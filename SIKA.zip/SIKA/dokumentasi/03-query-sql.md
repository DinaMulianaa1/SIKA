\# 3. QUERY SQL DATABASE SIKA



\## 3.1 Menampilkan Data



Menampilkan seluruh data mahasiswa:



```sql

SELECT \* FROM mahasiswa;

```



Menampilkan kolom tertentu:



```sql

SELECT nim, nama, email FROM mahasiswa;

```



\## 3.2 Menggunakan WHERE



Mencari mahasiswa berdasarkan angkatan:



```sql

SELECT \* FROM mahasiswa WHERE angkatan = 2024;

```



\## 3.3 Menggunakan LIKE



Mencari nama mahasiswa yang mengandung huruf tertentu:



```sql

SELECT nim, nama FROM mahasiswa WHERE nama LIKE '%a%';

```



\## 3.4 Menggunakan ORDER BY



Mengurutkan nama mahasiswa dari A sampai Z:



```sql

SELECT nim, nama FROM mahasiswa ORDER BY nama ASC;

```



Mengurutkan dari Z sampai A:



```sql

SELECT nim, nama FROM mahasiswa ORDER BY nama DESC;

```



\## 3.5 Menggunakan LIMIT



Menampilkan lima mahasiswa pertama:



```sql

SELECT nim, nama FROM mahasiswa ORDER BY nim LIMIT 5;

```



\## 3.6 Menggunakan UPDATE



Mengubah nama mahasiswa berdasarkan NIM:



```sql

UPDATE mahasiswa SET nama = 'Nama Baru' WHERE nim = 'NIM\_MAHASISWA';

```



Catatan: Ganti NIM\_MAHASISWA dengan NIM yang benar.



\## 3.7 Menggunakan DELETE



Menghapus data berdasarkan NIM:



```sql

DELETE FROM mahasiswa WHERE nim = 'TEST001';

```



Perintah DELETE harus menggunakan WHERE agar tidak menghapus seluruh data.



\## 3.8 Fungsi Agregasi



Menghitung jumlah mahasiswa:



```sql

SELECT COUNT(\*) AS total\_mahasiswa FROM mahasiswa;

```



Menghitung jumlah program studi:



```sql

SELECT COUNT(\*) AS total\_prodi FROM prodi;

```



\## 3.9 Menggunakan GROUP BY



Menghitung mahasiswa berdasarkan angkatan:



```sql

SELECT angkatan, COUNT(\*) AS jumlah\_mahasiswa FROM mahasiswa GROUP BY angkatan;

```



Menghitung mahasiswa berdasarkan program studi:



```sql

SELECT id\_prodi, COUNT(\*) AS jumlah\_mahasiswa FROM mahasiswa GROUP BY id\_prodi;

```



\## 3.10 Menggunakan JOIN



Menggabungkan mahasiswa dan program studi:



```sql

SELECT mahasiswa.nim, mahasiswa.nama, prodi.nama\_prodi FROM mahasiswa INNER JOIN prodi ON mahasiswa.id\_prodi = prodi.id\_prodi;

```



Menggabungkan data mahasiswa, KRS, dan mata kuliah:



```sql

SELECT mahasiswa.nama, mata\_kuliah.nama\_mk, mata\_kuliah.sks FROM mahasiswa INNER JOIN krs ON mahasiswa.nim = krs.nim INNER JOIN mata\_kuliah ON krs.kode\_mk = mata\_kuliah.kode\_mk;

```



\## 3.11 Kesimpulan



Perintah SQL digunakan untuk menampilkan, mencari, mengurutkan, menambah, mengubah, menghapus, menghitung, dan menggabungkan data dalam database SIKA.



