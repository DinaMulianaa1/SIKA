\# 5. BACKUP DAN RESTORE DATABASE SIKA



\## 5.1 Pendahuluan



Backup merupakan proses membuat salinan database untuk menghindari kehilangan data.



Restore merupakan proses mengembalikan database menggunakan file backup yang telah dibuat.



\## 5.2 Membuat Folder Backup



Folder backup dibuat di dalam direktori proyek SIKA.



```cmd

mkdir C:\\xampp\\htdocs\\sika\\database

```



\## 5.3 Melakukan Backup Database



Backup database dilakukan menggunakan perintah `mysqldump`.



```cmd

C:\\xampp\\mysql\\bin\\mysqldump -u root -p sika\_db > C:\\xampp\\htdocs\\sika\\database\\sika.sql

```



Masukkan password root MariaDB jika diminta.



\## 5.4 Memeriksa File Backup



Memeriksa file backup:



```cmd

dir C:\\xampp\\htdocs\\sika\\database

```



File yang diharapkan:



`sika.sql`



\## 5.5 Membuat Database Restore



Membuat database baru untuk pengujian pemulihan:



```sql

CREATE DATABASE sika\_restore;

```



\## 5.6 Melakukan Restore Database



Restore dilakukan melalui CMD Windows:



```cmd

C:\\xampp\\mysql\\bin\\mysql -u root -p sika\_restore < C:\\xampp\\htdocs\\sika\\database\\sika.sql

```



Masukkan password root jika diminta.



\## 5.7 Memeriksa Hasil Restore



Masuk ke MariaDB dan pilih database hasil restore:



```sql

USE sika\_restore;

```



Melihat tabel:



```sql

SHOW TABLES;

```



Menghitung jumlah mahasiswa:



```sql

SELECT COUNT(\*) AS total\_mahasiswa FROM mahasiswa;

```



Menghitung jumlah program studi:



```sql

SELECT COUNT(\*) AS total\_prodi FROM prodi;

```



\## 5.8 Kesimpulan



Proses backup dan restore membantu menjaga keamanan dan ketersediaan data database SIKA. File `sika.sql` dapat digunakan untuk memulihkan database ketika diperlukan.

